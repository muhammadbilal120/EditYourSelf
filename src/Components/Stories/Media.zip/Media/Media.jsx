import { InputContext } from '../../../UseContext'
import { FaLeftLong } from "react-icons/fa6";
import { IoMdClose } from "react-icons/io";
import React, { useContext } from 'react'
import { FaCheck } from "react-icons/fa";
import { Link } from 'react-router-dom'
import "./Media.css"
function Media() {
    const { selectedImage, setSelectedImage, setStickers, setFilter, setShowMediapic,setInputData } = useContext(InputContext);

    const handleImageChange = (event) => {
        const file = event.target.files[0];
        const reader = new FileReader();
        reader.onloadend = () => {
            setSelectedImage(reader.result);
            setStickers([]);
            setInputData('')
            setFilter('');
        };
        if (file) {
            reader.readAsDataURL(file);
            setShowMediapic(false);
        }
    };

    const openFileDialog = () => {
        document.getElementById('fileInput').click();
    };
    return (
        <div className="Container">
            <header className="header-btn" >
                <button className="nav-btn"><Link to={"/"}><FaLeftLong style={{ marginLeft: "-10px", color: "whitesmoke" }} /></Link></button>
            </header>
            <div className="mediapic">
                {selectedImage && <img src={selectedImage} alt="Selected media" />}
                <div className='upload-new-pic'>
                    <input
                        type="file"
                        id="fileInput"
                        style={{ display: 'none' }}
                        accept="image/*"
                        onChange={handleImageChange}
                    />
                </div>
            </div>
            <div className='Bottom-media'>
                <div className="Controls-media">
                    <div className="Control-media">
                        <Link to={"/"}>
                            <IoMdClose size={30} color='white' />
                        </Link>
                    </div>
                    <button className='media-dailog-btn' onClick={openFileDialog}>
                        <svg
                            aria-hidden="true"
                            stroke="currentColor"
                            stroke-width="2"
                            viewBox="0 0 24 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                stroke-width="2"
                                stroke="#fffffff"
                                d="M13.5 3H12H8C6.34315 3 5 4.34315 5 6V18C5 19.6569 6.34315 21 8 21H11M13.5 3L19 8.625M13.5 3V7.625C13.5 8.17728 13.9477 8.625 14.5 8.625H19M19 8.625V11.8125"
                                stroke-linejoin="round"
                                stroke-linecap="round"
                            ></path>
                            <path
                                stroke-linejoin="round"
                                stroke-linecap="round"
                                stroke-width="2"
                                stroke="#fffffff"
                                d="M17 15V18M17 21V18M17 18H14M17 18H20"
                            ></path>
                        </svg>
                        ADD FILE
                    </button>
                    <div className="Control-media">
                        <Link to={"/FontName"}>
                            <FaCheck size={25} color='white' />
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Media